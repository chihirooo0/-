from django.contrib import admin
from .models import Resume
from django.shortcuts import render, redirect
from django.http import HttpResponseForbidden


class ResumeAdmin(admin.ModelAdmin):
    list_display = ('full_name', 'age', 'country', 'city')

    def add_resume(self, request):
        if request.method == "POST":
            csrf_token = request.POST.get('csrfmiddlewaretoken')
            if not csrf_token or csrf_token != request.META.get('CSRF_COOKIE'):
                return HttpResponseForbidden("CSRF token missing or incorrect")

            return redirect('admin:app_name_resume_changelist')

        return render(request, 'add_resume_template.html')

admin.site.register(Resume, ResumeAdmin)

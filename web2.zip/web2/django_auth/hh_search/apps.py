from django.apps import AppConfig


class HhSearchConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'hh_search'

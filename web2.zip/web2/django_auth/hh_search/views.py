from .forms import  ResumeSearchForm, ResumeForm
from django.db.models import Q
import requests
from .models import Resume
from django.shortcuts import render, redirect

def search_vacancies(request):
    keyword = request.GET.get("keyword", "")
    vacancies = []

    if keyword:
        url = "https://api.hh.ru/vacancies"
        headers = {
            "User-Agent": "Freedom/1.0"
        }
        params = {
            "text": keyword,
            "area": 113,
            "per_page": 10
        }

        response = requests.get(url, headers=headers, params=params)

        if response.status_code == 200:
            vacancies = response.json().get("items", [])
        else:
            print("Ошибка поиска вакансий:", response.status_code, response.text)

    return render(request, "search_vacancies.html", {"vacancies": vacancies, "keyword": keyword})

def view_vacancy(request, vacancy_id):
    url = f"https://api.hh.ru/vacancies/{vacancy_id}"
    headers = {
        "User-Agent": "Freedom/1.0"
    }

    response = requests.get(url, headers=headers)

    if response.status_code == 200:
        vacancy = response.json()
    else:
        print("Ошибка получения информации о вакансии:", response.status_code, response.text)
        vacancy = None

    return render(request, "view_vacancy.html", {"vacancy": vacancy})

def add_resume(request):
    if request.method == "POST":
        form = ResumeForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('/hh/add_resume/')
    else:
        form = ResumeForm()
    return render(request, 'add_resume.html', {'form': form})

def resume_list(request):
    resumes = Resume.objects.all()
    return render(request, 'resume_list.html', {'resumes': resumes})

def search_resumes(request):
    form = ResumeSearchForm(request.GET)
    resumes = Resume.objects.all()

    if form.is_valid():
        bank_position = form.cleaned_data.get('bank_position')
        if bank_position and bank_position != 'none':
            resumes = resumes.filter(bank_position=bank_position)

        min_age = form.cleaned_data.get('min_age')
        if min_age:
            resumes = resumes.filter(age__gte=min_age)

        max_age = form.cleaned_data.get('max_age')
        if max_age:
            resumes = resumes.filter(age__lte=max_age)

        education = form.cleaned_data.get('education')
        if education and education != 'none':
            resumes = resumes.filter(education=education)

        work_experience = form.cleaned_data.get('work_experience')
        if work_experience and work_experience != 'none':
            resumes = resumes.filter(work_experience=work_experience)

        country = form.cleaned_data.get('country')
        if country:
            resumes = resumes.filter(country=country)

        city = form.cleaned_data.get('city')
        if city and city != 'none':
            resumes = resumes.filter(city=city)

    return render(request, 'search_resumes.html', {'form': form, 'resumes': resumes})

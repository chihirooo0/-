from django.urls import path
from . import views

urlpatterns = [
    path("search_vacancies/", views.search_vacancies, name="search_vacancies"),
    path("vacancy/<int:vacancy_id>/", views.view_vacancy, name="view_vacancy"),  # Маршрут для просмотра вакансии
    path('add_resume/', views.add_resume, name='add_resume'),
    path('resume_list/', views.resume_list, name='resume_list'),
    path('search/', views.search_resumes, name='search_resumes'),
]

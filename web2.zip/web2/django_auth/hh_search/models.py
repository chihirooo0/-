from django.db import models

class Resume(models.Model):
    CITY_CHOICES = [
        ('none', 'Нет'),
        ('Almaty', 'Алматы'),
        ('Astana', 'Астана'),
        ('Shymkent', 'Шымкент'),
        ('Aktobe', 'Актобе'),
        ('Karaganda', 'Караганда'),
        ('Taraz', 'Тараз'),
        ('Pavlodar', 'Павлодар'),
        ('Ust-Kamenogorsk', 'Усть-Каменогорск'),
        ('Semey', 'Семей'),
        ('Atyrau', 'Атырау'),
        ('Kostanay', 'Костанай'),
        ('Kyzylorda', 'Кызылорда'),
        ('Petropavlovsk', 'Петропавловск'),
        ('Aktau', 'Актау'),
        ('Turkestan', 'Туркестан'),
        ('Temirtau', 'Темиртау'),
        ('Kokshetau', 'Кокшетау'),
        ('Taldykorgan', 'Талдыкорган'),
        ('Ekibastuz', 'Экибастуз'),
    ]
    WORK_EXPERIENCE_CHOICES = [
        ('none', 'Нет'),
        ('1-3', 'От 1 до 3 лет'),
        ('3-5', 'От 3 до 5 лет'),
        ('5-8', 'От 5 до 8 лет'),
        ('8+', 'Более 8 лет'),
    ]
    EDUCATION_CHOICES = [
        ('none', 'Нет'),
        ('secondary', 'Среднее'),
        ('vocational', 'Средне специальное'),
        ('higher', 'Высшее'),
        ('bachelor', 'Бакалавр'),
        ('master', 'Магистр'),
    ]
    BANK_POSITION_CHOICES = [
        ('none', 'Нет'),
        ('client_manager', 'Менеджер по работе с клиентами'),
        ('business_process_technologist', 'Технолог по бизнес процессам'),
        ('methodologist', 'Методолог'),
        ('lms_manager', 'Менеджер LMS'),
        ('support_specialist', 'Специалист службы Технической Поддержки Руководства'),
        ('1c_developer', '1с Разработчик'),
        ('system_analyst', 'Системный аналитик'),
        ('system_architect', 'Системный архитектор'),
    ]

    full_name = models.CharField(max_length=100, verbose_name="ФИО", default="")
    age = models.IntegerField(verbose_name="Возраст", default="")
    country = models.CharField(max_length=25, verbose_name="Страна", default="Казахстан")  # Добавлен default
    city = models.CharField(max_length=20, choices=CITY_CHOICES, verbose_name="Город", default="none")
    work_experience = models.CharField(max_length=10, choices=WORK_EXPERIENCE_CHOICES, verbose_name="Опыт работы", default="none")
    education = models.CharField(max_length=20, choices=EDUCATION_CHOICES, verbose_name="Образование", default="none")
    bank_position = models.CharField(max_length=30, choices=BANK_POSITION_CHOICES, verbose_name="Должность в банке", default="none")
    description = models.TextField(verbose_name="Описание", default="")
    additional_info = models.TextField(verbose_name="Дополнительная информация", blank=True, null=True)

    def __str__(self):
        return f"{self.full_name} - {self.age} лет - {self.country}, {self.city}, {self.bank_position}"

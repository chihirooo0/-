from django import forms
from .models import Resume

class ResumeForm(forms.ModelForm):
    class Meta:
        model = Resume
        fields = ['full_name', 'age', 'country', 'city', 'bank_position', 'work_experience', 'education', 'description', 'additional_info']




class ResumeSearchForm(forms.Form):
    bank_position = forms.ChoiceField(
        choices=Resume.BANK_POSITION_CHOICES,
        required=False,
        label="Должность"
    )
    min_age = forms.IntegerField(required=False, label="Минимальный возраст")
    max_age = forms.IntegerField(required=False, label="Максимальный возраст")
    education = forms.ChoiceField(
        choices=Resume.EDUCATION_CHOICES,
        required=False,
        label="Образование"
    )
    work_experience = forms.ChoiceField(
        choices=Resume.WORK_EXPERIENCE_CHOICES,
        required=False,
        label="Опыт работы"
    )
    city = forms.ChoiceField(
        choices=Resume.CITY_CHOICES,
        required=False,
        label="Город"
    )


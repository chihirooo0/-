from allauth.account.views import LoginView
from .forms import CustomLoginForm
from allauth.account.views import ConfirmEmailView

from django.shortcuts import render, redirect
from allauth.socialaccount.models import SocialApp

from django.urls import reverse
from django.views.generic import TemplateView
from allauth.account.utils import complete_signup

from allauth.account.views import SignupView

class CustomSignupView(SignupView):
    def get_success_url(self):
        return reverse('account_login')

    def form_valid(self, form):
        response = super().form_valid(form)
        return response
    

def custom_social_login_view(request, provider):
    if not SocialApp.objects.filter(provider=provider).exists():
        return redirect('account_login')

    if provider == 'google':
        template_name = 'account/google_login.html'
    elif provider == 'vk':
        template_name = 'account/vk_login.html'
    else:
        template_name = 'socialaccount/login.html'

    return render(request, template_name)


    
class CustomConfirmEmailView(ConfirmEmailView):
    def get(self, request, *args, **kwargs):
        response = super().get(request, *args, **kwargs)
        user = self.get_object()
        if user.is_active:
            print("Аккаунт подтвержден.")
        else:
            print("Аккаунт не подтвержден.")
        return response

class CustomLoginView(LoginView):
    form_class = CustomLoginForm

    def form_valid(self, form):
        self.login(form)
        return super().form_valid(form)


def home(request):
    return render(request, 'base.html')



from django.urls import path, include
from .views import CustomLoginView, home, custom_social_login_view, CustomSignupView

urlpatterns = [
    path('', home, name='home'),
    path('accounts/', include('allauth.urls')),
    path('accounts/login/', CustomLoginView.as_view(), name='account_login'),
    path('accounts/login/<str:provider>/', custom_social_login_view, name='custom_social_login'),
    path('accounts/signup/', CustomSignupView.as_view(), name='account_signup'),
]

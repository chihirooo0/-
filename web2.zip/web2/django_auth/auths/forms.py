from django import forms
from allauth.account.forms import LoginForm
from allauth.account.forms import SignupForm

class CustomSignupForm(SignupForm):
    def save(self, request):
        user = super().save(request)
        return user


class CustomLoginForm(LoginForm):
    def clean(self):
        email = self.cleaned_data.get('login')
        password = self.cleaned_data.get('password')
        
        if not email:
            raise forms.ValidationError("Email не может быть пустым.")
        if not password:
            raise forms.ValidationError("Пароль не может быть пустым.")

        return super().clean()
